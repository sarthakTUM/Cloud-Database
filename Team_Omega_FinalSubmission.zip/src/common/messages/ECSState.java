package common.messages;

public enum ECSState {
	INITIALIZED, START, STOP, SHUTDOWN

}
