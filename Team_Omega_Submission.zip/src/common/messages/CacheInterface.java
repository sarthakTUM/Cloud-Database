package common.messages;

public interface CacheInterface {

	public String get(String Key);
	public void put(String Key, String Value);
}
